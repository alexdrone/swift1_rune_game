//
//  PauseScene.m
//  elements
//
//  Created by Luca on 24/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PauseGameScene.h"


@implementation PauseGameScene

+(id) scene
{
	CCScene *scene = [CCScene node];	
	PauseGameScene *layer = [[PauseGameScene alloc] init];
	[scene addChild: layer];
	[layer release];
	
	return scene;
}

-(id) init
{

	if( (self=[super init] )) {		
		
		//particles
		CCParticleSystemQuad *emitter = [CCParticleSystemQuad particleWithFile:@"bkg2.plist"];
		emitter.position = ccp(240,160);
				
		[self addChild:emitter z:0];

		
		CCLabelTTF *resumeLabel  = [CCLabelTTF labelWithString:@"Resume" fontName:@"Arial Rounded MT Bold" fontSize:20];
		CCMenuItemLabel *resume  = [CCMenuItemLabel itemWithLabel:resumeLabel target:self selector:@selector(resume:)];
		
		CCLabelTTF *restartLabel = [CCLabelTTF labelWithString:@"Restart" fontName:@"Arial Rounded MT Bold" fontSize:20];
		CCMenuItemLabel *restart = [CCMenuItemLabel itemWithLabel:restartLabel target:self selector:@selector(restart:)];
		
		CCLabelTTF *exitLabel  = [CCLabelTTF labelWithString:@"Exit" fontName:@"Arial Rounded MT Bold" fontSize:20];
		CCMenuItemLabel *exit  = [CCMenuItemLabel itemWithLabel:exitLabel target:self selector:@selector(backmenu:)];
		
		
		CCMenu *menu = [CCMenu menuWithItems:  resume, restart, exit, nil];
		
        [menu alignItemsVertically];
        [self addChild:menu];
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}

/*-(void) registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
    return YES;
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event {
	[[CCDirector sharedDirector] popScene]; 
}*/

- (void) resume:(id) sender
{
	[[CCDirector sharedDirector] popScene];
	
	
}

- (void) restart:(id) sender
{
	[[CCDirector sharedDirector] popScene];
	[[CCDirector sharedDirector] replaceScene:[BlockGameScene scene]];
}

- (void) backmenu:(id) sender
{
	[[CCDirector sharedDirector] popScene];
	[[CCDirector sharedDirector] replaceScene:[Menu scene]];
}
@end
