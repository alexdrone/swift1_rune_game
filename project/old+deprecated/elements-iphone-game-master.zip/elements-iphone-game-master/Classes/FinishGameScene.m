//
//  FinishGameScene.m
//  elements
//
//  Created by Luca on 24/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FinishGameScene.h"


@implementation FinishGameScene

+(id) sceneWithScore:(NSInteger)score gameover:(BOOL)gameover
{
	CCScene *scene = [CCScene node];	
	FinishGameScene *layer = [[FinishGameScene alloc] initWithScore:score gameover:gameover];
	[scene addChild: layer];
	[layer release];
	
	return scene;
}

-(id) initWithScore:(NSInteger)score gameover:(BOOL)gameover

{
	
	if( (self=[super init] )) {	
		NSString *msg;

		if (gameover)
			msg = [NSString stringWithFormat:@"Game Over with Score: %d", score];
		else
			msg = [NSString stringWithFormat:@"Win with Score: %d", score];
			
		CCLabelTTF *label = [CCLabelTTF labelWithString:msg fontName:@"Arial Rounded MT Bold" fontSize:20];
		CGSize size = [[CCDirector sharedDirector] winSize];
		label.position =  ccp( size.width /2 , size.height/2 );
		[self addChild: label];
		self.isTouchEnabled = YES;
		
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}

-(void) registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
    return YES;
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event {
	[[CCDirector sharedDirector] popScene]; 
}


@end
