//
//  PlayerBlock.h
//  elements
//
//  Created by Alex Drone on 20/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Block.h"

@interface PlayerBlock : Block {
	CCSprite *spinner;
	CCParticleSystem *emitter;
}

@property(nonatomic, retain) CCSprite *spinner;
@property(nonatomic, retain) CCParticleSystem *emitter;

@end
