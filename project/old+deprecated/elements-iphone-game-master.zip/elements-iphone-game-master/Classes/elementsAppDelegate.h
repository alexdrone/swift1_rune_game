//
//  elementsAppDelegate.h
//  elements
//
//  Created by Alex Drone on 18/01/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BlockGameScene.h"
#import "Menu.h"


@class RootViewController;

@interface elementsAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow			*window;
	RootViewController	*viewController;
}

@property (nonatomic, retain) UIWindow *window;

@end
