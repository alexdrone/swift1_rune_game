//
//  BlockGameScene.h
//  elements
//
//  Created by Alex Drone on 19/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "CCTouchDispatcher.h"
#import "SimpleAudioEngine.h"
#import "BlockGameScene.h"
#import "Menu.h"

@interface PauseGameScene : CCLayer {

}

+(id) scene;
-(id) init;

@end