//
//  BlockGameScene.m
//  elements
//
//  Created by Alex Drone on 19/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BlockGameScene.h"

@implementation BlockGameScene

@synthesize levelBlocks, player, oldPosition, statusBar, points, time, level, toRemove, pause;

+(id) scene 
{
	return [BlockGameScene loadLevel:0 points:0];
}

+(CCScene*)loadLevel:(NSInteger)level points:(NSInteger)points
{	
	CCScene *scene = [CCScene node];	
	[scene removeAllChildrenWithCleanup:YES];

	NSString *file = [NSString stringWithFormat:@"level%d", level];
	NSString *data = [NSString stringWithContentsOfFile: [[NSBundle mainBundle] pathForResource:file ofType: @"json"] 
											   encoding: NSUTF8StringEncoding 
												  error: nil];
	
	BlockGameScene *layer = [[BlockGameScene alloc] initWithJSON:data points:points level:level];	
	[scene addChild: layer];
	[layer release];
	
	return scene;
}

-(id) initWithJSON:(NSString *)json points:(NSInteger)p level:(NSInteger)l
{
	if( (self = [super init] )) {

		self.toRemove = [[NSMutableArray alloc] init];
		
		//background
		CCSprite *bkg = [CCSprite spriteWithFile:@"background.png"];
		bkg.position = ccp(240,160);
		//bkg.opacity = 240;
		[self addChild:bkg];

		CCParticleSystemQuad *emitter = [CCParticleSystemQuad particleWithFile:@"bkg.plist"];
		emitter.position = ccp(240,160);
	
		[self addChild:emitter z:0];
		
		//pause button
		self.pause = [CCSprite spriteWithFile:@"pause-button.png"];
		pause.position = ccp (465, 305);
		pause.opacity = 150;
		[self addChild:pause z:2];
		
		//status Bar
		self.statusBar = [CCSprite spriteWithFile:@"statusBar.png"];
		statusBar.position = ccp(240, 305);
		[self addChild:statusBar];
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"points: N/A • time: N/A" fontName:@"Arial Rounded MT Bold" fontSize:13];
		label.position = ccp(80, 10);
		[self.statusBar addChild:label z:1 tag:1];
		self.statusBar.opacity = 70;
		
		self.levelBlocks = [[NSMutableArray alloc] init];
		
		//points and level
		self.points = p;
		self.level = l;
		self.time = 200;
		
		//parsing JSON
		//data[0] = level, data[1] = player, data[2..n] = blocks
		NSArray *data = [json JSONValue];
		
		NSDictionary *levelData  = [[data objectAtIndex:0] objectForKey:@"level"];
		self.time = [[levelData objectForKey:@"time"] intValue];
		
		//player data
		NSDictionary *playerData = [[data objectAtIndex:1] objectForKey:@"player"];
		
		self.player = [[PlayerBlock alloc] initWithDictionary:playerData];
		self.oldPosition = self.player.position;
		[self addChild:player];
		
		//blocks data
		int i;
		for (i = 2; i < [data count]; i++) {
			
			NSDictionary *d = [[data objectAtIndex:i] objectForKey:@"block"];
			
			Block *b = [[Block alloc] initWithDictionary:d];
			[self addChild:b];			
			[levelBlocks addObject:b];
			
			[b release];
		}
		
		//next frame scheduler
		[self schedule:@selector(nextFrame:)];
		self.isTouchEnabled = YES;
		
		//play background music
		[[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"bg.mp3"];
		
		//level timer
		[self schedule:@selector(timerEvent:) interval:1.0f];

		//level label
		NSString *levelName = [NSString stringWithFormat:@"Grid %d", self.level+1];
		CCLabelTTF *levelLabel = [CCLabelTTF labelWithString:levelName fontName:@"Arial Rounded MT Bold" fontSize:25];
		levelLabel.position = ccp(240, 150);
		[self addChild:levelLabel];
		
		[levelLabel runAction:[CCFadeOut actionWithDuration:2]];
	}
	
	return self;
}

- (void) dealloc
{
	[self removeAllChildrenWithCleanup:YES];
	[levelBlocks release];
	[toRemove release];
	[player release];
	[super dealloc];
}

- (void) registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

- (void) nextFrame:(ccTime)dt 
{
	//well done
	if ([levelBlocks count] == 0) [self levelDone];
		 
	//rotation
	for (Block *s in levelBlocks) s.sprite.rotation += 10*dt;
	self.player.sprite.rotation += 10*dt;
	self.player.spinner.rotation += 360*dt;
		
	//collision
	int i = 0;
	for (; i < [levelBlocks count]; i++) {
		
		Block *s = [levelBlocks objectAtIndex:i];
		
		if (CGRectIntersectsRect([player getBlockSize],[s getBlockSize])) {
			
			//incompatible block
			if (s.blockColor != player.blockColor && s.blockShape != player.blockShape) {
								
				[[SimpleAudioEngine sharedEngine] playEffect:@"bad.mp3"];

				[self.player stopAllActions];
				self.player.position = self.oldPosition;
				
				self.points -= 10;
				
				//show -10 points
				CCLabelTTF *pointsGained = [CCLabelTTF labelWithString:@"- 10" fontName:@"Arial Rounded MT Bold" fontSize:10];
				[self addChild:pointsGained];
				pointsGained.position = player.position;
				pointsGained.color = ccRED;
				[pointsGained runAction:[CCFadeOut actionWithDuration:.3]];
				
				CCBlink *blink = [CCBlink actionWithDuration:1.0 blinks:5];
				[s runAction:blink];
				
				[player.sprite runAction:blink];
			}
			
			//compatible block
			if (s.blockColor == player.blockColor || s.blockShape == player.blockShape) { 
				
				[self.levelBlocks removeObjectAtIndex:i];
				[self.toRemove addObject:s];
				[self.player changeShape:s.blockShape andColor:s.blockColor];
				
				self.player.position = s.position;

				[[SimpleAudioEngine sharedEngine] playEffect:@"good.mp3"];

				//popping sequence (after is called removeBlock)
				CCSequence *popSequence =  [CCSequence actions:
										   [CCScaleTo actionWithDuration:.1 scale:.5], 
										   [CCScaleTo actionWithDuration:.1 scale:2], 
										   [CCCallFunc actionWithTarget:self selector:@selector(removeBlock)], nil];
				[s runAction:popSequence];
			
				self.points += 10;
			}
			
		}
	}
	
	self.oldPosition = self.player.position;
}

- (void) removeBlock
{
	int i = 0;
	for (; i < [toRemove count]; i++) {
		Block *s = [toRemove objectAtIndex:i];
		
		//show + 10 points
		CCLabelTTF *pointsGained = [CCLabelTTF labelWithString:@"+ 10" fontName:@"Arial Rounded MT Bold" fontSize:10];
		[self addChild:pointsGained];
		pointsGained.position = s.position;
		pointsGained.color = ccGREEN;
		[pointsGained runAction:[CCFadeOut actionWithDuration:.3]];
		
		//remove the element from the layer graph
		[self removeChild:s cleanup:YES];	
		[toRemove removeObjectAtIndex:i];
	}
}

- (BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event 
{
	CGPoint location = [self convertTouchToNodeSpace: touch];
	
	//on tap pause button
	CGRect pauseRect = CGRectMake(self.pause.position.x, self.pause.position.y, 30, 30);
	CGRect touchRect = CGRectMake(location.x, location.y, 10, 10);
	
	if (CGRectIntersectsRect(pauseRect, touchRect)) {
		[[CCDirector sharedDirector] pushScene:[PauseGameScene scene]];
		return NO;
	}
	
	[player stopAllActions];
	[player runAction: [CCMoveTo actionWithDuration:ccpDistance(player.position, location)/200 position:location]];    

	return YES;
}

- (void) ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location = [self convertTouchToNodeSpace: touch];
	
	[player stopAllActions];
	[player runAction: [CCMoveTo actionWithDuration:ccpDistance(player.position, location)/200 position:location]];    	
}

- (void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event {
	[player stopAllActions];
}

- (void) timerEvent:(ccTime)dt 
{
	//one second is gone
	self.time -= 1;	

	//update the status bar
	CCLabelTTF *status = (CCLabelTTF *) [self.statusBar getChildByTag:1];
	[status setString:[NSString stringWithFormat:@"points : %d • time : %d", self.points, self.time, self.level]];
	
	//game over
	if (self.time <= 0) {
		[player stopAllActions];
		self.isTouchEnabled = NO;
		
		[self unscheduleAllSelectors];
		
		[[CCDirector sharedDirector] replaceScene: [FinishGameScene sceneWithScore:self.points gameover:YES]];
	}
}
		 
- (void) pointsForTimeLeft:(ccTime)dt 
{
	CCLabelTTF *label = (CCLabelTTF *) [self getChildByTag:99];
	
	if (self.time > 0) { 
		[label setString:[NSString stringWithFormat:@"time bonus: + %3d pts = %5d pts", 5 * self.time, self.points]];
		self.time--;
		self.points += 5;
	
	} else {
		
		//level change
		if (self.level + 1 == kLevelNumber)
			[[CCDirector sharedDirector] replaceScene: [FinishGameScene sceneWithScore:self.points gameover:NO]];
		
		else
			[[CCDirector sharedDirector] replaceScene: [BlockGameScene loadLevel:self.level+1 points:self.points]];
	}
	
}

- (void) levelDone
{		
	//todo: show time increment
	[[SimpleAudioEngine sharedEngine] playEffect:@"leveldone.mp3"];
	
	CCAction *playerFadeOut = [CCFadeOut actionWithDuration:.05*self.time];
	self.player.spinner.opacity = 0;
	[self.player.sprite runAction:playerFadeOut];


	[self unscheduleAllSelectors];
	
	CCLabelTTF *label = [CCLabelTTF labelWithString:@"" fontName:@"Arial Rounded MT Bold" fontSize:15];
	label.opacity = 180;
	label.color = ccORANGE;
	CGSize size = [[CCDirector sharedDirector] winSize];
	label.position = ccp(size.width /2 , size.height/2 - 100);
	[self addChild: label z:3 tag:99];

	[self schedule:@selector(pointsForTimeLeft:) interval:.05f];
}

@end
