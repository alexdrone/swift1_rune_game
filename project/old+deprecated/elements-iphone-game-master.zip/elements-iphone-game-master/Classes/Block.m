//
//  Block.m
//  elements
//
//  Created by Alex Drone on 19/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Block.h"


@implementation Block

@synthesize blockShape, blockColor, destroyed, sprite;

- (void) dealloc 
{
	[sprite release];
	[super dealloc];
}

- (id) initWithShape:(BlockShapeType) aShape andColor:(BlockColorType) aColor
{
	if (self = [super init]) {
		
		self.blockShape = aShape;
		self.blockColor = aColor;
		
		self.sprite = [CCSprite spriteWithFile:[self spriteName]];
		//self.sprite.position = self.position;
		[self addChild:sprite z:2];
		
	}
	
	return self;
}

- (id) initWithDictionary:(NSDictionary *)d
{
	NSString *sColor = [d objectForKey:@"color"];
	BlockColorType color = kGreen;
	
	if ([sColor isEqualToString:@"red"])    color = kRed;
	if ([sColor isEqualToString:@"blue"])   color = kBlue;
	if ([sColor isEqualToString:@"purple"]) color = kPurple;
	if ([sColor isEqualToString:@"yellow"]) color = kYellow;
	if ([sColor isEqualToString:@"green"])  color = kGreen;
	
	NSString *sType = [d objectForKey:@"shape"];
	BlockShapeType type = kSquare;
	
	if ([sType isEqualToString:@"circle"])   type = kCircle;
	if ([sType isEqualToString:@"square"])   type = kSquare;
	if ([sType isEqualToString:@"triangle"]) type = kTriangle;
	
	if (self = [self initWithShape:type andColor:color]) {
		
		NSInteger x, y;
		x = [[d objectForKey:@"x"] intValue];
		y = [[d objectForKey:@"y"] intValue];
		
		self.position = ccp(x, y);
	}
	
	return self;
}

- (void) changeShape:(BlockShapeType) aShape andColor:(BlockColorType) aColor
{
	
	self.blockShape = aShape;
	self.blockColor = aColor;
	
	[self removeChild:self.sprite cleanup:YES];
	
	self.sprite = [CCSprite spriteWithFile:[self spriteName]];
	[self addChild:sprite];
}

- (CGRect) getBlockSize
{
    double sx = self.position.x;
    double sy = self.position.y;
    return CGRectMake(sx, sy, 20, 20);
}

- (NSString *) spriteName 
{
	NSString *shapeName, *colorName;
	
	if (self.blockShape == kSquare)	 shapeName = @"square";
	if (self.blockShape == kCircle)   shapeName = @"circle";
	if (self.blockShape == kTriangle) shapeName = @"triangle";
	
	if (self.blockColor == kBlue)   colorName = @"blue";
	if (self.blockColor == kRed)    colorName = @"red";
	if (self.blockColor == kGreen)  colorName = @"green";
	if (self.blockColor == kPurple) colorName = @"purple";
	if (self.blockColor == kYellow) colorName = @"yellow";
	
	return [NSString stringWithFormat:@"%@_%@.png", shapeName, colorName];
}

@end
