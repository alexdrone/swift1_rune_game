//
//  FinishGameScene.h
//  elements
//
//  Created by Luca on 24/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "CCTouchDispatcher.h"

@interface FinishGameScene : CCLayer {

}

+(id) sceneWithScore:(NSInteger)score gameover:(BOOL)gameover;
-(id) initWithScore:(NSInteger)score gameover:(BOOL)gameover;


@end
