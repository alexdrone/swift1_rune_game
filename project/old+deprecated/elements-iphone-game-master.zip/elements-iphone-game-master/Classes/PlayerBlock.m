//
//  PlayerBlock.m
//  elements
//
//  Created by Alex Drone on 20/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlayerBlock.h"


@implementation PlayerBlock

@synthesize spinner, emitter;

- (id) initWithShape:(BlockShapeType) aShape andColor:(BlockColorType) aColor
{
	if (self = [super initWithShape:aShape andColor:aColor]) {
		
		self.spinner = [CCSprite spriteWithFile:@"player.png"];
		self.spinner.position = ccp(0,0);
		self.spinner.opacity = 80;
		[self addChild:self.spinner z:2];
		
		//particle emitter
		//self.emitter = [CCParticleSystemQuad particleWithFile:@"bkg.plist"];
		//self.emitter.position = self.position;
		//[self addChild:self.emitter z:0];
		
	}
	
	return self;
}



@end
