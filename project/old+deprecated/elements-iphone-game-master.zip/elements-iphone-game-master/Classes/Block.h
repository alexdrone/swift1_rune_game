//
//  Block.h
//  elements
//
//  Created by Alex Drone on 19/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

typedef enum { kRed, kPurple, kGreen, kBlue, kYellow } BlockColorType;
typedef enum { kSquare, kCircle, kTriangle, } BlockShapeType;

@interface Block : CCNode 
{
	BlockColorType blockColor;
	BlockShapeType blockShape;
	CCSprite *sprite;
	Boolean destroyed;	
}

@property(nonatomic) BlockColorType blockColor;
@property(nonatomic) BlockShapeType blockShape;
@property(nonatomic, retain) CCSprite *sprite;
@property(nonatomic) Boolean destroyed;


- (id) initWithShape:(BlockShapeType) aShape andColor:(BlockColorType) aColor;
- (id) initWithDictionary:(NSDictionary *)d;

- (void) changeShape:(BlockShapeType) aShape andColor:(BlockColorType) aColor;
- (NSString *) spriteName;
- (CGRect) getBlockSize;

@end
