//
//  BlockGameScene.h
//  elements
//
//  Created by Alex Drone on 19/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SimpleAudioEngine.h"
#import "JSON.h"
#import "Block.h"
#import "PlayerBlock.h"
#import "PauseGameScene.h"
#import "FinishGameScene.h"

#define kTopUIHeight 30
#define kLevelNumber 10

@interface BlockGameScene : CCLayer {
	NSMutableArray *levelBlocks;
	NSMutableArray *toRemove;
	
	PlayerBlock *player;

	CGPoint oldPosition;
	
	CCSprite *statusBar;
	CCSprite *pause;
	
	NSInteger points, time, level;
}

@property(nonatomic,retain) NSMutableArray *levelBlocks;
@property(nonatomic,retain) NSMutableArray *toRemove;
@property(nonatomic,retain) PlayerBlock *player;
@property(nonatomic,retain) CCSprite *statusBar;
@property(nonatomic,retain) CCSprite *pause;
@property(nonatomic) CGPoint oldPosition;
@property(nonatomic) NSInteger points;
@property(nonatomic) NSInteger time;
@property(nonatomic) NSInteger level;

+(id) scene;
+(CCScene*)loadLevel:(NSInteger)level points:(NSInteger)points;
-(id) initWithJSON:(NSString *)json points:(NSInteger)p level:(NSInteger)l;
-(void)levelDone;


@end
