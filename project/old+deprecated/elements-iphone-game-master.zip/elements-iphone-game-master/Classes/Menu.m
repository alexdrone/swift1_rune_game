//
//  Menu.m
//  elements
//
//  Created by Luca on 01/02/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Menu.h"


@implementation Menu
+(id) scene
{
	CCScene *scene = [CCScene node];	
	Menu *layer = [[Menu alloc] init];
	[scene addChild: layer];
	[layer release];
	
	return scene;
}

-(id) init
{
	self = [super init];
	
	if (self) {
		
		//background
		CCSprite *bkg = [CCSprite spriteWithFile:@"title.png"];
		bkg.position = ccp(240,160);
		//bkg.opacity = 240;
		[self addChild:bkg];
		
		//particles
		CCParticleSystemQuad *emitter = [CCParticleSystemQuad particleWithFile:@"bkg.plist"];
		emitter.position = ccp(240,160);
		
		[self addChild:emitter z:0];
		
		CCLabelTTF *startLabel  = [CCLabelTTF labelWithString:@"New Game" fontName:@"Arial Rounded MT Bold" fontSize:20];
		CCMenuItemLabel *start  = [CCMenuItemLabel itemWithLabel:startLabel target:self selector:@selector(start:)];
		
		CCLabelTTF *scoresLabel = [CCLabelTTF labelWithString:@"Highscore" fontName:@"Arial Rounded MT Bold" fontSize:20];
		CCMenuItemLabel *scores = [CCMenuItemLabel itemWithLabel:scoresLabel target:self selector:@selector(highScores:)];

		CCLabelTTF *aboutLabel  = [CCLabelTTF labelWithString:@"About" fontName:@"Arial Rounded MT Bold" fontSize:20];
		CCMenuItemLabel *about  = [CCMenuItemLabel itemWithLabel:aboutLabel target:self selector:@selector(about:)];
		
		CCMenu *m = [CCMenu menuWithItems:  start, scores, about, nil];
		
        [m alignItemsVertically];
        [self addChild:m];
	}
	
	return self;
}


- (void) about:(id) sender
{
}

- (void) highScores:(id) sender
{
}

- (void) start:(id) sender
{
	[[CCDirector sharedDirector] replaceScene: [BlockGameScene scene]];
}

- (void) dealloc
{
	[super dealloc];
}


@end
